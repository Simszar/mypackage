# mypackage
This libracy was creates as an example of how to publish your own python package

# how to install
# md means mark down

